<!DOCTYPE html>
<html lang="en">
<head>
    <meta charset="UTF-8">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <title>Calculo de Temperatura</title>

</head>
<body>
    <h2>Calculo de temperatura</h2>
    <form method="post" action="">
        <for="temp">Numero:</label>
        <input type="number" step="0.01" name="temp" id="temp" required>
        <input type="submit" value="Verificar a Temperatura">
        </form>
    <?php
    if ($_SERVER["REQUEST_METHOD"] == "POST") {
      
        $temp = isset($_POST['numero']) ?  intval($_POST['temp']) : 0;
        
        if ($temp <= 10) {
            echo "<p>O Clima está frio.</p>";
        } elseif ($temp >= 20) {
            echo "<p>O Clima está calor.</p>";
        }
    }
?>
</body>
</html>