<!DOCTYPE html>
<html lang="en">
<head>
    <meta charset="UTF-8">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <title>Verificação Impar ou Par</title>

</head>
<body>
    <h2>Verificação Impar ou Par</h2>
    <form method="post" action="">
        <for="num">Numero:</label>
        <input type="number" step="0.01" name="num" id="num" required>
        <input type="submit" value="Verificar">
        </form>
    <?php
    if ($_SERVER["REQUEST_METHOD"] == "POST") {
      
        $num = isset($_POST['numero']) ?  intval($_POST['num']) : 0;
        
        if ($num % 2 == 0) {
            echo "<p>O numero inserido é Par.</p>";
        } else {
            echo "<p>O numero inserido é Impar.</p>";
        }
    }
?>
</body>
</html>