
<!DOCTYPE html>
<html lang="pt-BR">
<head>
    <meta charset="UTF-8">
    <title>Notas e Aprovação</title>
</head>
<body>
    <h2>Aprovação ou Reprovação</h2>
    <form method="post" action="">
        <label for="nota">Informe a nota do aluno:</label>
        <input type="number" step="0.01" name="nota" id="nota" required>
        <input type="submit" value="Verificar Situação">
    </form>

    <?php
    
    if ($_SERVER["REQUEST_METHOD"] == "POST") {
      
        $nota = isset($_POST['nota']) ? floatval($_POST['nota']) : 0;

    
        if ($nota >= 7) {
            $situacao = " O aulo está Aprovado";
        } elseif ($nota >= 5) {
            $situacao = "O aulo está de Recuperação";
        } else {
            $situacao = "O aulo está Reprovado";
        }

        echo "<h3>Resultado</h3>";
        echo "Nota do Aluno: " . number_format($nota, 2) . "<br>";
        echo "Situação: <strong>$situacao</strong>";
    }
    ?>
</body>
</html>
