<!DOCTYPE html>
<html lang="pt-br">
<head>
    <meta charset="UTF-8">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <title>Dia da Semana</title>
</head>
<body>
    <h1>Informe um número de 1 a 7</h1>
    <form method="post" action="">
        <label for="numero">Número:</label>
        <input type="number" id="numero" name="numero" min="1" max="7" required>
        <input type="submit" value="Enviar">
    </form>

    <?php if (isset($dia)): ?>
        <p>Dia da semana correspondente: <?php echo htmlspecialchars($dia); ?></p>
    <?php endif; ?>

    <?php
// Verifica se o formulário foi enviado
if ($_SERVER["REQUEST_METHOD"] == "POST") {
    // Obtém o número enviado pelo formulário
    $numero = isset($_POST['numero']) ? intval($_POST['numero']) : 0;

    // Mapeia o número para o dia da semana
    switch ($numero) {
        case 1:
            $dia = "Segunda-feira";
            break;
        case 2:
            $dia = "Terça-feira";
            break;
        case 3:
            $dia = "Quarta-feira";
            break;
        case 4:
            $dia = "Quinta-feira";
            break;
        case 5:
            $dia = "Sexta-feira";
            break;
        case 6:
            $dia = "Sábado";
            break;
        case 7:
            $dia = "Domingo";
            break;
        default:
            $dia = "Número inválido. Por favor, insira um número de 1 a 7.";
            break;
    }
}
?>
</body>
</html>
