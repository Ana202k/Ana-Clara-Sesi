<!DOCTYPE html>
<html lang="pt-BR">
<head>
    <meta charset="UTF-8">
    <title>Faixa Etária</title>
</head>
<body>
    <h2>Determinação da Faixa Etária</h2>
    <form method="post" action="">
        <label for="idade">Informe a idade:</label>
        <input type="number" name="idade" id="idade" min="0" required>
        <input type="submit" value="Verificar Faixa Etária">
    </form>

    <?php
    
    if ($_SERVER["REQUEST_METHOD"] == "POST") {
        
        $idade = isset($_POST['idade']) ? intval($_POST['idade']) : 0;

       
        if ($idade >= 0 && $idade <= 12) {
            $faixaEtaria = "Criança";
        } elseif ($idade >= 13 && $idade <= 17) {
            $faixaEtaria = "Adolescente";
        } elseif ($idade >= 18 && $idade <= 64) {
            $faixaEtaria = "Adulto";
        } elseif ($idade >= 65) {
            $faixaEtaria = "Idoso";
        } else {
            $faixaEtaria = "Idade inválida";
        }

       
        echo "<h3>Resultado</h3>";
        echo "Idade: " . $idade . "<br>";
        echo "Faixa Etária: <strong>$faixaEtaria</strong>";
    }
    ?>
</body>
</html>
