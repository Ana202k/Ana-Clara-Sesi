<!DOCTYPE html>
<html lang="en">
<head>
    <meta charset="UTF-8">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <title>Calculo da Média</title>

</head>
<body>
    <h2>Calculo da Média</h2>
    <form method="post" action="">
        <for="nota1">Nota 1:</label>
        <input type="number" step="0.01" name="nota1" id="nota1" required>
        <for="nota1">Nota 2:</label>
        <input type="number" step="0.01" name="nota2" id="nota2" required>
        <for="nota1">Nota 3:</label>
        <input type="number" step="0.01" name="nota3" id="nota3" required>
        <for="nota1">Nota 4:</label>
        <input type="number" step="0.01" name="nota4" id="nota4" required>
        <for="nota1">Nota 5:</label>
        <input type="number" step="0.01" name="nota5" id="nota5" required>
        <input type="submit" value="Calcular Média">
    </form>
    <?php
    if ($_SERVER["REQUEST_METHOD"] == "POST") {
        
        $nota1 = isset($_POST['nota1']) ? floatval($_POST['nota1']) : 0;
        $nota2 = isset($_POST['nota2']) ? floatval($_POST['nota2']) : 0;
        $nota3 = isset($_POST['nota3']) ? floatval($_POST['nota3']) : 0;
        $nota4 = isset($_POST['nota4']) ? floatval($_POST['nota4']) : 0;
        $nota5 = isset($_POST['nota5']) ? floatval($_POST['nota5']) : 0;

        $media = ($nota1 + $nota2 + $nota3 + $nota4 + $nota5) / 5;
        echo "<h3>Resultado</h3>";
        echo "Média das Notas: " . number_format($media, 2) . "<br>";

        if ($media >= 6) {
            echo "<p>O aluno está APROVADO.</p>";
        } else {
            echo "<p>O aluno está REPROVADO.</p>";
        }
    }
    ?>
</body>
</html>

