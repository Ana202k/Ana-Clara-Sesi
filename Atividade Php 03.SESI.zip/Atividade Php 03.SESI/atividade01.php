<?php
function calcularFrete($peso) {
    if ($peso <= 1) {
        return 10.00;
    } elseif ($peso <= 5) {
        return 15.00;
    } elseif ($peso <= 10) {
        return 20.00;
    } else {
        return 25.00;
    }
}

$frete = null; 
$peso = null; 

if ($_SERVER["REQUEST_METHOD"] == "POST") {
    $peso = $_POST['peso'];
    
   
    if (is_numeric($peso) && $peso >= 0) {
        $frete = calcularFrete($peso);
    } else {
        $frete = "Por favor, insira um valor válido para o peso.";
    }
}
?>

<!DOCTYPE html>
<html lang="pt-BR">
<head>
    <meta charset="UTF-8">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <title>Cálculo de Frete</title>
</head>
<body>
    <h1>Cálculo de Frete</h1>
    <form method="POST" action="">
        <label for="peso">Insira o peso em kg:</label>
        <input type="text" name="peso" id="peso" required>
        <button type="submit">Calcular Frete</button>
    </form>

    <?php if ($frete !== null): ?>
        <h2>Resultado:</h2>
        <p>O valor do frete para <?= htmlspecialchars($peso) ?> kg é R$ <?= number_format($frete, 2, ',', '.') ?></p>
    <?php endif; ?>
</body>
</html>
