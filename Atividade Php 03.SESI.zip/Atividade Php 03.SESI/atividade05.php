<?php
function calcularTempoViagem($distancia, $velocidade) {
    
    $tempoHoras = $distancia / $velocidade;

   
    $horas = floor($tempoHoras); 
    $minutos = round(($tempoHoras - $horas) * 60); 

    return [$horas, $minutos]; 
}

$distancia = null; 
$velocidade = null; 
$tempoViagem = null; 

if ($_SERVER["REQUEST_METHOD"] == "POST") {
    
    $distancia = $_POST['distancia'];
    $velocidade = $_POST['velocidade'];

    
    if (is_numeric($distancia) && is_numeric($velocidade) && $distancia > 0 && $velocidade > 0) {
        list($horas, $minutos) = calcularTempoViagem(floatval($distancia), floatval($velocidade));
        $tempoViagem = [$horas, $minutos]; 
    } else {
        $tempoViagem = "Por favor, insira valores válidos para a distância e a velocidade.";
    }
}
?>

<!DOCTYPE html>
<html lang="pt-BR">
<head>
    <meta charset="UTF-8">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <title>Calculadora de Tempo de Viagem</title>
</head>
<body>
    <h1>Calculadora de Tempo de Viagem</h1>
    <form method="POST" action="">
        <label for="distancia">Distância (km):</label>
        <input type="text" name="distancia" id="distancia" required><br>

        <label for="velocidade">Velocidade Média (km/h):</label>
        <input type="text" name="velocidade" id="velocidade" required><br>

        <button type="submit">Calcular Tempo</button>
    </form>

    <?php if ($tempoViagem !== null): ?>
        <h2>Resultado:</h2>
        <?php if (is_array($tempoViagem)): ?>
            <p>O tempo de viagem será de <?= $tempoViagem[0] ?> horas e <?= $tempoViagem[1] ?> minutos.</p>
        <?php else: ?>
            <p><?= $tempoViagem ?></p>
        <?php endif; ?>
    <?php endif; ?>
</body>
</html>
