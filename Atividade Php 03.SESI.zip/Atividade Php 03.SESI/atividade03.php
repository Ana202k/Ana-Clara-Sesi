<?php
function calcularImpostoRenda($salarioBruto) {
    $imposto = 0;

    if ($salarioBruto <= 1903.98) {
       
        return 0;
    } elseif ($salarioBruto <= 2826.65) {
        $imposto = ($salarioBruto * 0.075) - 142.80;
    } elseif ($salarioBruto <= 3751.05) {
        $imposto = ($salarioBruto * 0.15) - 354.80;
    } elseif ($salarioBruto <= 4664.68) {
        $imposto = ($salarioBruto * 0.225) - 636.13;
    } else {
        $imposto = ($salarioBruto * 0.275) - 869.36;
    }

    return max($imposto, 0);
}

$imposto = null; 
$salarioBruto = null; 
if ($_SERVER["REQUEST_METHOD"] == "POST") {
  
    $salarioBruto = $_POST['salarioBruto'];

   
    $salarioBruto = str_replace(['.', ','], ['', '.'], trim($salarioBruto)); 

    
    if (is_numeric($salarioBruto) && $salarioBruto >= 0) {
        $imposto = calcularImpostoRenda(floatval($salarioBruto)); /
    } else {
        $imposto = "Por favor, insira um valor válido para o salário.";
    }
}
?>

<!DOCTYPE html>
<html lang="pt-BR">
<head>
    <meta charset="UTF-8">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <title>Calculadora de Imposto de Renda</title>
</head>
<body>
    <h1>Calculadora de Imposto de Renda</h1>
    <form method="POST" action="">
        <label for="salarioBruto">Salário Bruto (R$):</label>
        <input type="text" name="salarioBruto" id="salarioBruto" required><br>

        <button type="submit">Calcular Imposto</button>
    </form>

    <?php if ($imposto !== null): ?>
        <h2>Resultado:</h2>
        <p>O imposto de renda a ser pago sobre um salário bruto de R$ <?= number_format($salarioBruto, 2, ',', '.') ?> é R$ <?= number_format($imposto, 2, ',', '.') ?></p>
    <?php endif; ?>
</body>
</html>
