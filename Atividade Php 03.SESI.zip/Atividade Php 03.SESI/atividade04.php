<?php
function calcularPontos($valorCompra) {
    if ($valorCompra <= 50.00) {
        return 5; 
    } elseif ($valorCompra <= 100.00) {
        return 10; 
    } else {
        return 15; 
    }
}

$pontos = null; 
$valorCompra = null; 

if ($_SERVER["REQUEST_METHOD"] == "POST") {
    
    $valorCompra = $_POST['valorCompra'];

   
    $valorCompra = str_replace(',', '.', trim($valorCompra));

   
    if (is_numeric($valorCompra) && $valorCompra >= 0) {
        $pontos = calcularPontos(floatval($valorCompra)); 
    } else {
        $pontos = "Por favor, insira um valor válido para a compra.";
    }
}
?>

<!DOCTYPE html>
<html lang="pt-BR">
<head>
    <meta charset="UTF-8">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <title>Calculadora de Pontos de Acumulação</title>
</head>
<body>
    <h1>Calculadora de Pontos de Acumulação</h1>
    <form method="POST" action="">
        <label for="valorCompra">Valor da Compra (R$):</label>
        <input type="text" name="valorCompra" id="valorCompra" required><br>

        <button type="submit">Calcular Pontos</button>
    </form>

    <?php if ($pontos !== null): ?>
        <h2>Resultado:</h2>
        <p>Você acumulou <?= $pontos ?> pontos para uma compra de R$ <?= number_format($valorCompra, 2, ',', '.') ?>.</p>
    <?php endif; ?>
</body>
</html>
